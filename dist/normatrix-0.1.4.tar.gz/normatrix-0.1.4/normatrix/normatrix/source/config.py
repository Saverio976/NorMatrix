LIBC_BANNED_FUNC = [
        'printf',
        'memset',
        'stcpy',
        'strcat'
]
