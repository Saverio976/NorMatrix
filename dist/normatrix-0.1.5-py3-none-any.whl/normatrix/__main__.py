from normatrix.source.main import main

main()
